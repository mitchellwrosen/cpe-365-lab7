cpe-365-lab7
============
Matthew Tondreau (mmtondre)
Mitchell Rosen (mwrosen)
Charlie Shaeffer (cshaeffe)

http://users.csc.calpoly.edu/~dekhtyar/365-Fall2012/labs/lab7.365.pdf

To run via command line:

   make all; ./a.out
